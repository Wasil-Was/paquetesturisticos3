const con = require('../ConnectBD');

//CONSULTAS:
var selectReserva = 'SELECT paquete_cliente.ID_Paquete, paquete_cliente.rut_cliente, paquete.cantPersonas, paquete.valorNoche from paquete_cliente join paquete on (paquete.ID_Paquete = paquete_cliente.ID_Paquete)';

exports.mostrar = (req, res) =>{
    con.query(selectReserva, (err, result) => {
        if(!err){
            res.render('back_reservas.ejs',{
                paquete_cliente: result
            });
        }
        else {
            console.log(err);
        }
    })
}