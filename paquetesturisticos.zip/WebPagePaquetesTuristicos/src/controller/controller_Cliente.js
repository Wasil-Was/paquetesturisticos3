const con = require('../ConnectBD');

//CONSULTAS:
var insertInCliente = 'INSERT into cliente SET ?';
var updateInCliente = 'UPDATE cliente SET ? WHERE rut = ?';
var selectAll_RutCliente = 'SELECT * FROM cliente WHERE rut = ?';
var selectCliente = 'SELECT rut, nombre, telefono, email from cliente';
var deletefromCliente = 'DELETE FROM cliente WHERE rut = ?';

exports.mostrar = (req, res) =>{
    con.query(selectCliente, (err, result) => {
        if(!err){
            res.render('back_clientes.ejs',{
                cliente: result
            });
        }
        else {
            console.log(err);
        }
    });
}

exports.crear = (req,res)=>{
    const {rut,nombre,telefono,email,fechaNac} = req.body;
    //console.log(req.body);
    //res.send('Received');
    con.query(insertInCliente ,{
        rut: rut,
        nombre: nombre,
        telefono: telefono,
        email: email,
        fechaNac: fechaNac
    },(err, result) =>{
        if(!err){
            res.redirect('/back_clientes');
        }
        else {
            console.log(err);
        }
    });
}

exports.modificar = (req, res) =>{
    const {id,rut,nombre,telefono,email,fechaNac} = req.body;
    //console.log(req.body);
    con.query(updateInCliente,[{
        rut: rut,
        nombre: nombre,
        telefono: telefono,
        email: email,
        fechaNac: fechaNac},
        id
    ],(err, result) =>{ 
        if(!err){
            res.redirect('/back_clientes');
        }
        else {
            console.log(err);
        }
    });
}


exports.id = (req, res) =>{
    const {id} = req.params;
    con.query(selectAll_RutCliente, [id], (error, results) =>{
        if(!error){
            res.render('cliente/modificar_cliente', {cliente: results[0]});
            //console.log(results[0]);
            //console.log(id);
        }
        else {
            console.log(error);
        }
    });
}

exports.eliminar = (req, res) =>{
    const {rut} = req.params;
    con.query(deletefromCliente, [rut], (err, result) =>{
        if(!err){
            res.redirect('/back_clientes');
        }
        else {
            console.log(err);
        }
    });
}