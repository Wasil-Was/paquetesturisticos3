//db.tasks.distinct("cliente.pago");
//SELECT
var selectAll_Paquete = 'SELECT * FROM paquete';
var selectAll_Cliente = 'SELECT * FROM cliente';
var selectAll_PaqueteCliente = 'SELECT * FROM PAQUETE_CLIENTE'
var selectCliente_PagoMayor600000 = 'SELECT cliente.nombre, cliente.rut, pago.valor from cliente inner join pago on cliente.rut = pago.rut_cliente where pago.valor > 600000';
var selectVuelo_CapacMayor500 = 'SELECT ID_Vuelo, modeloAvion, capacidad from vuelo where capacidad >= 500';
var selectRutaFromVuelo = 'SELECT ruta.ID_Ruta, ruta.paisOrigen, ruta.paisDestino, vuelo.modeloAvion from ruta inner join vuelo on vuelo.ID_Vuelo = ruta.ID_Vuelo';
//INSERT
var insertNewRuta = "INSERT INTO ruta(ID_Ruta, ID_Vuelo, aeropuertoOrigen, aeropuertoDestino, paisOrigen, paisDestino, fechaIda, fechaVuelta, horaSalida, horahVuelta) values ?";
var data01 = [
    ['1616', '186', 'Aeropuerto de Chile', 'Aeropuerto de Uruguay', 'Chile', 'Uruguay', '2021-12-1', '2022-02-1', '00:00', '1:30']
];
var insertNewVuelo = "INSERT INTO vuelo(ID_Vuelo, modeloAvion, capacidad) values ?";
var data = [
    ['686', 'Boeing 727', '50']
];
var insertNewPasaje = "INSERT INTO pasaje(ID_Pasaje, ID_Paquete, rutPasajero, clase, asiento, valor) values ?";
var data = [
    ['80686', '1001', '12467895', 'Economica', '69', '300000']
];
//DELETE
var deleteIDfromPasaje = 'DELETE from pasaje where ID_Pasaje = 80686';
var deleteIDfromVuelo = 'DELETE from vuelo where ID_Vuelo = 686';
//UPDATE
var updateRutaAerOrigen = 'UPDATE ruta set aeropuertoOrigen = "Aeropuerto Internacional Arturo Merino Benítez" where AeropuertoOrigen = "Aeropuerto de Chile"';
var updateVueloModAvion = 'UPDATE vuelo set modeloAvion = "Boeing 777" where modeloAvion = "Boeing 747"';
//CREATE
var createTablaGenerica = 'CREATE table TablaGenerica (nombre varchar(20) NOT NULL, apellido varchar(20) NOT NULL, edad int NOT NULL, telefono int NOT NULL)';
//ALTER
var alterTabGenerica_Rut = 'ALTER table TablaGenerica add rut varchar(10) NOT NULL first';
var alterTabGenerica_AddPrimary = 'ALTER table TablaGenerica add primary key (rut)';
var dropTabGenerica = 'DROP table TablaGenerica';
//OPERADORES y SUBCONSULTAS "SELECT ID_Paquete, rut_cliente from pasaje"
var selectVueloIfRuta_Brasil = "SELECT vuelo.id_vuelo, paisOrigen, paisDestino, aeropuertoOrigen, aeropuertoDestino from ruta inner join vuelo on ruta.id_vuelo = vuelo.id_vuelo where ruta.id_vuelo in (select id_vuelo from vuelo where paisDestino='Brasil')";
var selectVueloIfNotAvion = "SELECT vuelo.id_pasaje, vuelo.id_vuelo, valor from pasaje join vuelo on pasaje.id_pasaje = vuelo.id_pasaje where pasaje.id_pasaje not in (select id_vuelo from vuelo where modeloAvion='Boeing 777')";
var selectPagoIfExistCliente = 'SELECT pago.rut_cliente, nombre from cliente join pago on cliente.rut = pago.rut_cliente where exists (select rut_cliente from pago where cliente.rut = pago.rut_cliente)';
var selectVueloExistInRuta = 'SELECT ruta.id_vuelo, modeloAvion from vuelo join ruta on vuelo.id_vuelo = ruta.id_vuelo where ruta.id_vuelo in (select id_vuelo from vuelo)';
//FUNCIONES AGREGADAS
var selectAvionGroupCapacidad = 'SELECT modeloAvion, capacidad, count(capacidad) from vuelo join ruta on vuelo.id_vuelo = ruta.id_vuelo group by capacidad';
var selectTotalPagoCliente = 'SELECT pago.rut_cliente, cliente.nombre, sum(pago.valor) from pago join cliente on pago.rut_cliente = cliente.rut group by pago.rut_cliente';
var selectBeneficiosEmpresa = 'SELECT sum(pago.valor) from pago join cliente on pago.rut_cliente = cliente.rut';
//GROUP BY
var selectPaquetesFromCliente = 'SELECT pago.rut_cliente, cliente.nombre, count(pago.valor) from pago join cliente on pago.rut_cliente = cliente.rut group by pago.rut_cliente';
var selectAvionesGroupModelo = 'SELECT modeloAvion, count(modeloAvion) from vuelo join ruta on vuelo.id_vuelo = ruta.id_vuelo group by modeloAvion';
var selectRutasGroupPaisOrigen = 'SELECT paisOrigen, count(paisOrigen) from ruta join vuelo on ruta.id_vuelo = vuelo.id_vuelo group by paisOrigen';
var selectCountClaseComprada = 'SELECT clase, count(clase) from pasaje join vuelo on pasaje.id_pasaje = vuelo.id_pasaje group by clase';
var selectRutaGroupAeropuertoOrigen = 'SELECT aeropuertoOrigen, count(aeropuertoOrigen) from ruta join vuelo on ruta.id_vuelo = vuelo.id_vuelo group by aeropuertoOrigen';



/*
    con.query(insertNewRuta, [data01], (err, result) => {
        if(!err){
            res.render('back_paquetes.ejs',{
                ruta: result
            });
        }
        else {
            console.log(err);
        }
    });
    con.query(deleteIDfromPasaje, (err, result) => {
        if(!err){
            res.render('back_paquetes.ejs',{
                pasaje: result
            });
        }
        else {
            console.log(err);
        }
    });
*/

/*
//CONSULTAS ANTIGUAS:
//SELECT
con.query('SELECT cliente.Nombre, cliente.rut, cliente.ID_Paquete, pago.valor from cliente inner join pago on cliente.rut = pago.rut_cliente where pago.valor > 600000', (err,resp,campos) =>{
    console.log(resp);
});

con.query('SELECT ruta.ID_Ruta, ruta.paisOrigen, ruta.paisDestino, vuelo.modeloAvion from ruta inner join vuelo on ruta.ID_Ruta = vuelo.ID_Ruta', (err,resp,campos) =>{
    console.log(resp);
});
con.query('SELECT ID_Vuelo, modeloAvion, capacidad from vuelo where capacidad >= 500', (err,resp,campos) =>{
    console.log(resp);
});

//INSERT
var sql = "INSERT INTO ruta(ID_Ruta, aeropuertoOrigen, aeropuertoDestino, paisOrigen, paisDestino, fechaIda, fechaVuelta, horaSalida, horahVuelta) values ?";
var data = [
    ['1616', 'Aeropuerto de Chile', 'Aeropuerto de Uruguay', 'Chile', 'Uruguay', '2021-12-1', '2022-02-1', '00:00', '1:30']
];
  con.query(sql, [data], (err, resp, campos) =>{
    if (err) {
        return console.error(err.message);
    }
    console.log('\nObjetos Ingresados: ' + resp.affectedRows);
});

var sql = "INSERT INTO vuelo(ID_Vuelo, ID_Ruta, modeloAvion, capacidad) values ?";
var data = [
    ['686', '1616', 'Boeing 727', '50']
];
  con.query(sql, [data], (err, resp, campos) =>{
    if (err) {
        return console.error(err.message);
    }
    console.log('\nObjetos Ingresados: ' + resp.affectedRows);
});
var sql = "INSERT INTO pasaje(ID_Pasaje, ID_Vuelo, clase, asiento, valor) values ?";
var data = [
    ['80686', '686', 'Economica', '69', '300000']
];
  con.query(sql, [data], (err, resp, campos) =>{
    if (err) {
        return console.error(err.message);
    }
    console.log('\nObjetos Ingresados: ' + resp.affectedRows);
});

//DELETE
con.query('DELETE from pasaje where ID_Pasaje = 80686', (err,resp,campos) =>{
    console.log(resp);
});
con.query('DELETE from vuelo where ID_Vuelo = 686', (err,resp,campos) =>{
    console.log(resp);
});


//UPDATE
con.query('UPDATE ruta set aeropuertoOrigen = "Aeropuerto Internacional Arturo Merino Benítez" where AeropuertoOrigen = "Aeropuerto de Chile"', (err,resp,campos) =>{
    console.log(resp);
});
con.query('UPDATE vuelo set modeloAvion = "Boeing 777" where modeloAvion = "Boeing 747"', (err,resp,campos) =>{
    console.log(resp);
});



//CREATE
con.query('CREATE table TablaGenerica (nombre varchar(20) NOT NULL, apellido varchar(20) NOT NULL, edad int NOT NULL, telefono int NOT NULL)', (err,resp,campos) =>{
    console.log(resp);
});


//ALTER
con.query('ALTER table TablaGenerica add rut varchar(10) NOT NULL first', (err,resp,campos) =>{
    console.log(resp);
});
con.query('ALTER table TablaGenerica add primary key (rut)', (err,resp,campos) =>{
    console.log(resp);
});


//DROP
con.query('DROP table TablaGenerica', (err,resp,campos) =>{
    console.log(resp);
});
*/





/* EJEMPLOS:
//TEST
//console.log("Hola!");

con.query('SELECT * from paquetes', (err,resp,campos) =>{
    console.log(resp, "\n\n\n\n");
});

con.query('SELECT rut from paquetes', (err,resp,campos) =>{
    console.log(resp);
});

con.query('DELETE from paquetes WHERE paquetes.rut = 20483921', (err,resp,campos) =>{
    console.log(resp);
});

con.query('UPDATE paquetes SET rut="33333333" WHERE paquetes.rut = 22222222', (err,resp,campos) =>{
    console.log(resp);
});

var sql = "INSERT INTO paquetes(rut, vivo, edad, fechaDeNacimiento) VALUES ?";
var data = [
    ['20531130', '1', '21', '2000-05-12'],
    ['20031059', '0', '17', '1997-07-09'],
    ['20483921', '1', '21', '2000-09-15']
];
  con.query(sql, [data], (err, resp, campos) =>{
    if (err) {
        return console.error(err.message);
    }
    console.log('\nObjetos Ingresados: ' + resp.affectedRows);
});

  con.query('SELECT * from paquetes', (err,resp,campos) =>{
    console.log("\n\n\n\n",resp);
});
*/