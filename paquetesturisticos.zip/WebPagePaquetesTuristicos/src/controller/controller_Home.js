const con = require('../ConnectBD');

//CONSULTAS:
var selectDataFromPaquete = 'SELECT ID_Paquete, descripcion, valorNoche, ciudadDestino, paisDestino FROM paquete';

exports.mostrar = (req, res) =>{
    con.query(selectDataFromPaquete, (err, result) => {
        if(!err){
            res.render('home.ejs',{
                paquete: result
            });
        }
        else {
            console.log(err);
        }
    });
}