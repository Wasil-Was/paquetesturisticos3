const con = require('../ConnectBD');

//CONSULTAS:
var insertInPaquete = 'INSERT into paquete SET ?';
var updateInPaquete = 'UPDATE paquete SET ? WHERE ID_Paquete = ?';
var selectAll_IDPaquete = 'SELECT * FROM paquete WHERE ID_Paquete = ?';
var selectAll_Paquete = 'SELECT * FROM paquete';
var deletefromPaquete = 'DELETE FROM paquete WHERE ID_Paquete = ?';

exports.mostrar = (req, res) =>{
    con.query(selectAll_Paquete, (err, result) => {
        if(!err){
            res.render('back_paquetes.ejs',{
                paquete: result
            });
        }
        else {
            console.log(err);
        }
    });
}

exports.crear = (req,res)=>{
    const {ID_Paquete,descripcion,paisDestino,ciudadDestino,hospedaje,restaurante,automovil,cantPersonas,valorNoche} = req.body;
    //console.log(req.body);
    //res.send('Received');
    con.query(insertInPaquete ,{
        ID_Paquete: ID_Paquete,
        descripcion: descripcion,
        paisDestino: paisDestino,
        ciudadDestino: ciudadDestino,
        hospedaje: hospedaje,
        restaurante: restaurante,
        automovil: automovil,
        cantPersonas: cantPersonas,
        valorNoche: valorNoche
    },(err, result) =>{
        if(!err){
            res.redirect('/back_paquetes');
        }
        else {
            console.log(err);
        }
    });
}

exports.modificar = (req, res) =>{
    const {id,descripcion,paisDestino,ciudadDestino,hospedaje,restaurante,automovil,cantPersonas, valorNoche} = req.body;
    //console.log(req.body);
    con.query(updateInPaquete,[{
        descripcion: descripcion,
        paisDestino: paisDestino,
        ciudadDestino: ciudadDestino,
        hospedaje: hospedaje,
        restaurante: restaurante,
        automovil: automovil,
        cantPersonas: cantPersonas,
        valorNoche: valorNoche},
        id
    ],(err, result) =>{ 
        if(!err){
            res.redirect('/back_paquetes');
        }
        else {
            console.log(err);
        }
    })
}


exports.id = (req, res) =>{
    const {id} = req.params;
    con.query(selectAll_IDPaquete, [id], (error, results) =>{
        if(!error){
            res.render('paquete/modificar_paquete', {paquete: results[0]});
        }
        else {
            console.log(error);
        }
    });
}

exports.eliminar = (req, res) =>{
    const {id} = req.params;
    con.query(deletefromPaquete, [id], (err, result) =>{
        if(!err){
            res.redirect('/back_paquetes');
        }
        else {
            console.log(err);
        }
    });
}