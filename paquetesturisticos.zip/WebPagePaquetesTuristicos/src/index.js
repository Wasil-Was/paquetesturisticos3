var bodyParser = require ('body-parser');
const express = require ('express');
const path = require ('path');
const app = express();
const conn = require('./ConnectBD');
const cookieParser = require('cookie-parser');
const passport = require('passport');
const session = require('express-session');
const passportLocal = require('passport-local').Strategy;

//CONFIGURACIÓN INICIAL
app.set('port',process.env.PORT || 3000);


//VISTA:
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'view/pages'));
//Acceso Público a la carpeta 'images' y 'css'
app.use('/images', express.static(path.join(__dirname, 'view/images')));
app.use('/styles', express.static(path.join(__dirname, 'view/styles')));
app.use('/css', express.static(path.join(__dirname, 'view/styles/main.css')));
//MIDDLEWARE (Lógica de Intercambio de Información.)
app.use(bodyParser.urlencoded({extended: true})); //Analiza el texto como URL
app.use(express.json());

//LOGIN
app.use(cookieParser('ultra'));
app.use(session({
    secret: 'ultra',
    resave: true,
    saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session());
passport.use(new passportLocal(function(username,password,done){
    if(username == "admin" && password == "admin123456789")
        return done(null,{id: 1, name:"Administrador"});
    done(null, false);
}));
//Serialización
passport.serializeUser(function(user,done){
    done(null,user.id);
});
//Deserialización
passport.deserializeUser(function(id,done){
    done(null, {id: 1, name: "Administrador"});
});


//RUTAS (Rutas de datos e información.)
app.use(require('./routes/home'));
app.use(require('./routes/catalogo'));
app.use(require('./routes/login'));
app.use(require('./routes/back_paquetes'));
app.use(require('./routes/crear_paquete'));
app.use(require('./routes/modificar_paquete'));
app.use(require('./routes/back_reservas'));
app.use(require('./routes/back_clientes'));
app.use(require('./routes/crear_cliente'));
app.use(require('./routes/modificar_cliente'));
app.use(require('./routes/nosotros'));
app.use(require('./routes/contacto'));
//404
app.use(require('./routes/all_general'));


//SERVIDOR
app.listen(app.get('port'), () => {
    console.log('Servidor en Puerto',app.get('port'))
});