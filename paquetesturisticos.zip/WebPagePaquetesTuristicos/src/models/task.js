const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const TaskSchema = new Schema({
    ID_Paquete: String,
    descripcion: String,
    paisDestino: String,
    ciudadDestino: String,
    hospedaje: String,
    restaurante:String ,
    automovil: String,
    cantPersonas: Number,
    valorNoche: Number,
    cliente: [{
        rut: String,
        nombre: String,
        telefono: Number,
        email: String,
        fechaNac: { type : Date, default: Date.now },
        pago: [{
            ID_Boleta: Number,
            valor: Number
        }]
    }]
});
module.exports = mongoose.model('task', TaskSchema);