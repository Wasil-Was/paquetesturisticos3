const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');

//BACK RESERVAS
const controller = require("../controller/controller_Reservas");
//MOSTRAR RESERVAS
router.get('/back_reservas', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, controller.mostrar);

/*
//MOSTRAR PAQUETES
router.get('/back_reservas', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, async (req, res) =>{
    try{
        const tasks = await task.find({},{"ID_Paquete":1,"cantPersonas":1,"valorNoche":1,"cliente.rut":1,"_id":0});
        console.log(tasks);
        res.render('back_reservas.ejs',{
            paquete_cliente: tasks
        });
    }
    catch (error){
        console.log(error);
    }
});
*/
module.exports = router;