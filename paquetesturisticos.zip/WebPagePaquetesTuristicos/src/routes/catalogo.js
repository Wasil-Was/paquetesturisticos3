const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');

const controller = require("../controller/controller_Catalogo");
//MOSTRAR CATALOGO
router.get('/catalogo', controller.mostrar);

/*
//MOSTRAR CATALOGO
router.get('/catalogo', async (req, res) =>{
    try{
        const tasks = await task.find();
        //console.log(tasks);
        res.render('catalogo.ejs',{
            paquete: tasks
        });
    }
    catch (error){
        console.log(error);
    }
});
*/
module.exports = router;