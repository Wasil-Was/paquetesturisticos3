const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');

//404 ERROR
router.use((req, res, next) =>{
    res.status(404).render("404")
});
module.exports = router;

/*
con.query(SQL, (err,resp,campos) =>{
    console.log(resp);
});
*/