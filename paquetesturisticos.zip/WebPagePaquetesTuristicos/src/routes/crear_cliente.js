const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');


const controller = require("../controller/controller_Cliente");
//RENDERIZAR PAGINA
router.get('/back_clientes/crear', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, (req, res) =>{
    res.render('cliente/crear_cliente');
});


//CREAR CLIENTE
router.post('/back_clientes/crear', controller.crear);

/*
//CREAR CLIENTE
router.post('/back_clientes/crear', async (req, res) =>{
    const {rut,nombre,telefono,email,fechaNac} = req.body;
    try{
        const tasks = await task.create({
            rut: rut,
            nombre: nombre,
            telefono: telefono,
            email: email,
            fechaNac: fechaNac
            });
        console.log(tasks);
        res.redirect('/back_clientes');
    }
    catch (error){
        console.log(error);
    }
});
*/
module.exports = router;