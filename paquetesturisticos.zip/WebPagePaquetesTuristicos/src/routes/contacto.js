const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');

//CONTACTO
//RENDERIZAR PAGINA
router.get('/contacto', (req, res) =>{
    res.render('contacto.ejs');
});
module.exports = router;