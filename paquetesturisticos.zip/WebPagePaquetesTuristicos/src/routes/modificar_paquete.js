const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');

const controller = require("../controller/controller_Paquete");
//MUESTRA LOS DATOS DEL PAQUETE A MODIFICAR
router.get('/back_paquetes/modificar/:id', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, controller.id);

//MODIFICA EL PAQUETE
router.post('/back_paquetes/modificar', controller.modificar);


/*
//MUESTRA LOS DATOS DEL PAQUETE A MODIFICAR
router.get('/back_paquetes', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, async (req, res) =>{
    try{
        const {id} = req.params;
        const tasks = await task.find({"ID_Paquete": id},{"cliente":0});
        console.log(tasks);
        res.render('back_paquetes.ejs',{
            paquete: tasks
        });
    }
    catch (error){
        console.log(error);
    }
});

    
//MODIFICA EL PAQUETE
router.post('/back_paquetes', async (req, res) =>{
    const {id,descripcion,paisDestino,ciudadDestino,hospedaje,restaurante,automovil,cantPersonas, valorNoche} = req.body;
    try{
        const tasks = await task.update(
            { _id: id },
            {   ID_Paquete: ID_Paquete,
                descripcion: descripcion,
                paisDestino: paisDestino,
                ciudadDestino: ciudadDestino,
                hospedaje: hospedaje,
                restaurante: restaurante,
                automovil: automovil,
                cantPersonas: cantPersonas,
                valorNoche: valorNoche
            });
        console.log(tasks);
        res.render('back_paquetes.ejs',{
            paquete: tasks
        });
    }
    catch (error){
        console.log(error);
    }
});
*/
module.exports = router;