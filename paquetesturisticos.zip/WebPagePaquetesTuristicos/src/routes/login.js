const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const passport = require('passport');
const task = require('../models/task');

//LOGIN
//RENDERIZA EL LOGIN
router.get('/login', (req, res) =>{
    res.render('login.ejs');
});

//LOGIN
router.post('/login', passport.authenticate('local',{
    failureRedirect: "/login",
    //successFlash: "Welcome!",
    //failureFlash: "Invalid username or password."
}), function(req, res) {
    res.redirect(req.session.returnTo || '/');
    delete req.session.returnTo;
}); 
module.exports = router;