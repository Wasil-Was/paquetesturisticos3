const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');

//MODIFICAR CLIENTE
const controller = require("../controller/controller_Cliente");
//MUESTRA LOS DATOS DEL CLIENTE A MODIFICAR
router.get('/back_clientes/modificar/:id', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
},controller.id);

//MODIFICA EL CLIENTE
router.post('/back_clientes/modificar', controller.modificar);

/*
//MUESTRA LOS DATOS DEL CLIENTE A MODIFICAR
router.get('/back_paquetes', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, async (req, res) =>{
    try{
        const tasks = await task.find();
        console.log(tasks);
        res.render('back_paquetes.ejs',{
            paquete: tasks
        });
    }
    catch (error){
        console.log(error);
    }
});

//MODIFICA EL CLIENTE
router.post('/back_paquetes', async (req, res) =>{
    try{
        const tasks = await task.find();
        console.log(tasks);
        res.render('back_paquetes.ejs',{
            paquete: tasks
        });
    }
    catch (error){
        console.log(error);
    }
});
*/
module.exports = router;