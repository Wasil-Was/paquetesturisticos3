const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');

//BACK CLIENTES
const controller = require("../controller/controller_Cliente");
//MOSTRAR CLIENTES
router.get('/back_clientes', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
},controller.mostrar);

//ELIMINAR CLIENTE
router.get('/back_clientes/delete/:rut', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    res.redirect("/login");
},controller.eliminar);

/*
//MOSTRAR CLIENTES
router.get('/back_clientes', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, async (req, res) =>{
    try{
        var tasks = await task.distinct("cliente");
        //var repetidos = {};
        //tasks = tasks.filter(function(tasks) {
        //    if (tasks.rut in repetidos) {
        //        return false;
        //    } else {
        //        repetidos[tasks.rut] = true;
        //        return true;
        //    }
        //});
        console.log(tasks);
        res.render('back_clientes.ejs',{
            cliente: tasks
        });
    }
    catch (error){
        console.log(error);
    }
});

//ELIMINAR CLIENTE
router.get('/back_clientes/delete/:rut', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, async (req, res) =>{
    const {rut} = req.params;
    try{
        //const tasks = await task.remove({"cliente": {"cliente.rut": rut}});
        console.log(tasks);
        res.redirect('/back_clientes');
    }
    catch (error){
        console.log(error);
    }
});
*/
module.exports = router;