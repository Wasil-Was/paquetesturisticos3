const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');

//NOSOTROS
router.get('/nosotros', (req, res) =>{
    res.render('nosotros.ejs');
});
module.exports = router;

