const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');

//HOME
const controller = require("../controller/controller_Home");
//RENDERIZA EL HOME Y MUESTRA PAQUETES DESTACADOS
router.get('/', controller.mostrar);

/*
//RENDERIZA EL HOME Y MUESTRA PAQUETES DESTACADOS
router.get('/', async (req, res) =>{
    try{
        const tasks = await task.find();
        //console.log(tasks);
        res.render('home.ejs',{
            paquete: tasks
        });
    }
    catch (error){
        console.log(error);
    }
});
*/
module.exports = router;