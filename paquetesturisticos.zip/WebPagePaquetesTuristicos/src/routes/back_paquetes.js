const express = require('express');
const router = express.Router(); //Ayuda a moverse entre las distintas rutas.
const con = require('../ConnectBD');
const task = require('../models/task');

//BACK PAQUETES

//MOSTRAR PAQUETES
const controller = require("../controller/controller_Paquete");
router.get('/back_paquetes', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, controller.mostrar);

//ELIMINAR PAQUETE
router.get('/back_paquetes/delete/:id', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    res.redirect("/login");
}, controller.eliminar);

/*
//MOSTRAR PAQUETES
router.get('/back_paquetes', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, async (req, res) =>{
    try{
        const tasks = await task.find();
        console.log(tasks);
        res.render('back_paquetes.ejs',{
            paquete: tasks
        });
    }
    catch (error){
        console.log(error);
    }
});

//ELIMINAR PAQUETE
router.get('/back_paquetes/delete/:id', (req,res,next) =>{
    if(req.isAuthenticated()) return next();
    req.session.returnTo = req.originalUrl;
    res.redirect("/login");
}, async (req, res) =>{
    const {id} = req.params;
    try{
        const tasks = await task.deleteOne({"paquete.ID_Paquete": id});
        console.log(tasks);
        res.redirect('/back_paquetes');
    }
    catch (error){
        console.log(error);
    }
});
*/
module.exports = router;